package javafxtrial;

import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.Transition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;


public class StaticMethods 
    {
        private final static Button exit = new Button();
        private final static Button home = new Button();
        
        static public void showrules(Stage stage, Scene welcomescene)  
            {
                StackPane odigies = new StackPane();
                Scene odigiesscene = new Scene(odigies);   
                    odigies.setId("odigies");
                    stage.setScene(odigiesscene);
                Text gamerules = new Text
                                        (
                                            "ΟΔΗΓΙΕΣ ΠΑΙXΝΙΔΙΟΥ\n" +
                                            "\n" +
                                            "Η λέξη πρέπει να αποτελείται απο τουλάχιστον ΤΡΙΑ (3) ΕΛΛΗΝΙΚΑ γράμματα.\n" +
                                            "\n" +
                                            "Δεν επιτρέπονται τα ειδικά σύμβολα και οι αριθμοί.\n" +
                                            "\n" +
                                            "Ο παίκτης που μαντεύει την λέξη, εχει δικαίωμα να κάνει μέχρι και ΕΞΙ (6) λάθος μαντεψιές.\n" +
                                            "\n" +
                                            "Καλή διασκέδαση!"
                                        );
                    gamerules.setId("gamerules");
                    odigies.getStylesheets().add("styles/JavaFxTrial.css");
                    odigies.getChildren().add(gamerules);

                Button homepage = new Button ("<- Πίσω");
                    homepage.setId("homepage");
                    odigies.getChildren().add(homepage);
                    odigies.setAlignment(homepage, Pos.BOTTOM_LEFT);
                    odigies.setMargin(homepage, new Insets(40,40,40,125));
                    Handlers.addhomepagehandler(stage, homepage);
                
             }
        
        static public void welcomesetup(Scene welcomescene, Pane welcome, Stage Stage)
                {
                    Button instructions = new Button("Κανόνες");
                        instructions.setId("instructions");
                        welcome.setId("welcome");
                        welcome.getChildren().add(instructions);
                        instructions.setLayoutX(10);
                        instructions.setLayoutY(600);
                    
                    instructions.addEventHandler
                        (
                                MouseEvent.MOUSE_CLICKED, event ->  
                            {
                                showrules(Stage, welcomescene);
                            }
                        );
                }
        
        static public void addexitbutton(Stage Stage, Pane pane)
            {
                Image exitimage = new Image("styles/Images/exit.png");
                ImageView exitimageview = new ImageView(exitimage);
                    exitimageview.setId("exitimage");
                    exitimageview.setFitHeight(100);
                    exitimageview.setFitWidth(100);
                    exitimageview.setPreserveRatio(true);
                    exit.setGraphic(exitimageview);
                    exit.setLayoutX(Stage.getWidth()-165);
                    exit.setLayoutY(Stage.getHeight()-165);
                    exit.setId("exit");
                    pane.getChildren().add(exit);
                
                    exit.hoverProperty().addListener
                        (
                            event ->  
                                {
                                    RotateTransition exitrotatelone = new RotateTransition();
                                        exitrotatelone.setAxis(Rotate.Z_AXIS);
                                        exitrotatelone.setFromAngle(0);
                                        exitrotatelone.setToAngle(15);
                                        exitrotatelone.setAutoReverse(true);
                                        exitrotatelone.setDuration(Duration.millis(250));
                                        exitrotatelone.setNode(exit);

                                    RotateTransition exitrotater = new RotateTransition();
                                        exitrotater.setAxis(Rotate.Z_AXIS);
                                        exitrotater.setFromAngle(15);
                                        exitrotater.setToAngle(-15);
                                        exitrotater.setAutoReverse(true);
                                        exitrotater.setDuration(Duration.millis(250));
                                        exitrotater.setNode(exit);

                                    RotateTransition exitrotateltwo = new RotateTransition();
                                        exitrotateltwo.setAxis(Rotate.Z_AXIS);
                                        exitrotateltwo.setFromAngle(-15);
                                        exitrotateltwo.setToAngle(0);
                                        exitrotateltwo.setByAngle(15);
                                        exitrotateltwo.setAutoReverse(true);
                                        exitrotateltwo.setDuration(Duration.millis(250));
                                        exitrotateltwo.setNode(exit);

                                    SequentialTransition seqT = new SequentialTransition (exit, exitrotatelone, exitrotater, exitrotateltwo);
                                        seqT.play();

                                }
                        );


            }
        
            static public void addhomebutton(Stage Stage, Partida currentpartida)
                {
                    Transitions.Fade(home, 5000, 100.0);
                    home.setMouseTransparent(true);
                    Image homeimage = new Image("styles/Images/HomeButton.png");
                    ImageView homeimageview = new ImageView(homeimage);
                        homeimageview.setId("exitimage");
                        homeimageview.setFitHeight(75);
                        homeimageview.setFitWidth(75);
                        homeimageview.setPreserveRatio(true);
                        home.setGraphic(homeimageview);
                        home.setLayoutX(50);
                        home.setLayoutY(Stage.getHeight()-200);
                        home.setId("exit");
                        currentpartida.getcurrentwordpane().getplayingpane().getChildren().add(home);
                        
                        
                        Handlers.addhomehandler(Stage, currentpartida);
                        
                        home.hoverProperty().addListener
                            (
                                event ->  
                                    {
                                        SequentialTransition seqT = new SequentialTransition (Transitions.ScaleBy(home, 200, 0.2), Transitions.ScaleBy(home, 200, -0.2));
                                            seqT.play();

                                    }
                            );
                }
        
        static public void removeexitbutton(Pane pane)
            {
                pane.getChildren().remove(exit);
            }
        
        static public Button getexitbutton()
            {
                return exit;
            }
        
        static public Button gethomebutton()
            {
                return home;
            }
        
        static public void playsetup(Pane welcome)
            {
                //Κουμπί Play
                    Handlers.getPlay().setLayoutX(JavaFxTrial.getwidth()-64.5*JavaFxTrial.getwidth()/100);
                    welcome.getChildren().add(Handlers.getPlay()); 
                    Transitions.TranslateY(Handlers.getPlay(), 1200, -200, JavaFxTrial.getheight()-64*JavaFxTrial.getheight()/100);
                //Κουμπί Play
            }
        
        static public void removeplay(Pane welcome)
            {
                //Κουμπί Play
                    welcome.getChildren().remove(Handlers.getPlay()); 
                //Κουμπί Play
            }
    }