
package javafxtrial;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import static java.nio.charset.StandardCharsets.UTF_8;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import static javax.swing.JOptionPane.showMessageDialog;

public class Check 
    {
        public static void addgrammatahandlers(Stage Stage, Partida currentpartida)
            {
                for(Button i : currentpartida.getcurrentletters().getgrammata())
                            {
                                i.addEventHandler
                                    (
                                        MouseEvent.MOUSE_CLICKED, (var event) ->
                                            {
                                                try 
                                                    {
                                                        //System.out.println("Η λέξη είναι " + "(" + i.getText() + ") " + this.getWord());
                                                        checkletter(i, Stage, currentpartida);
                                                    } 
                                                catch (IOException ex) 
                                                    {
                                                        Logger.getLogger(Check.class.getName()).log(Level.SEVERE, null, ex);
                                                    }
                                            }
                                    );
                            }
            }
                
        public static void checknullword(Stage stage, Button Ekkinisi, Partida currentpartida)
            {
                String checkedstring;
                
                if (currentpartida.getcurrentwordpane().getwordf().getText().isEmpty()==false)
                    {
                        if(currentpartida.getcurrentwordpane().getwordf().getText().length()<3)
                            {
                                showMessageDialog(null, "Η λέξη δεν μπορεί να είναι μικρότερη από 3 χαρακτήρες");
                            }
                        else
                            {
                                Pattern digits = Pattern.compile("[0-9]");
                                Matcher digitsm = digits.matcher(currentpartida.getcurrentwordpane().getwordf().getText());
                                boolean digitsok = digitsm.find();
                                
                                if(digitsok)
                                    {
                                        showMessageDialog(null, "Η λέξη δεν μπορεί να περιέχει αριθμούς");
                                    }
                                else
                                    {
                                        Pattern specials = Pattern.compile("[!@#$%&*()_+=|<>?{}\\[\\]~-]");
                                        Matcher specialssm = specials.matcher(currentpartida.getcurrentwordpane().getwordf().getText());
                                        boolean specialsok = specialssm.find();
                                        
                                        if(specialsok)
                                            {
                                                showMessageDialog(null, "Η λέξη δεν μπορεί να περιέχει ειδικούς χαρακτήρες");
                                            }
                                        else
                                            {
                                                checkedstring=currentpartida.getcurrentwordpane().getwordf().getText();
                                                currentpartida.setlexi(checkedstring);
                                                currentpartida.getlexi().pinakessetup();
                                                currentpartida.getlexi().setlines();
                                                addgrammatahandlers(stage, currentpartida);
                                                currentpartida.getlexi().addlettertexts(currentpartida.getcurrentwordpane().getplayingpane());
                                                System.out.println("Checked String = " +  checkedstring);
                                                currentpartida.getcurrentwordpane().getprospathies().setId("prospathies");
                                                currentpartida.getcurrentwordpane().getprospathies().setLayoutX(1600);
                                                currentpartida.getcurrentwordpane().getprospathies().setLayoutY(150);
                                                currentpartida.getcurrentwordpane().getprospathies().setText(""+currentpartida.gettries());
                                                currentpartida.getcurrentwordpane().getplayingpane().getChildren().remove(currentpartida.getcurrentwordpane().getwordf());
                                                currentpartida.getcurrentwordpane().getplayingpane().getChildren().add(currentpartida.getcurrentwordpane().getprospathies());
                                                currentpartida.getcurrentwordpane().getplayingpane().getChildren().remove(Ekkinisi);
                                                //currentpartida.getcurrentwordpane().getplayingpane().getChildren().remove(Paiktis.getPaiktes().get(0).getNameLabel());
                                                //currentpartida.getcurrentwordpane().getplayingpane().getChildren().add(Paiktis.getPaiktes().get(1).getNameLabel());
                                                currentpartida.getcurrentwordpane().getcgwl().setText("Παίζει:");
                                                currentpartida.getcurrentwordpane().getcgwl().setLayoutX(JavaFxTrial.getwidth()-70*JavaFxTrial.getwidth()/100);
                                                Parts.addkremala(currentpartida);  
                                            }
                                    }
                            }
                    }
                else
                    {
                        showMessageDialog(null, "Για να ξεκινήσεις το παιχνίδι, πρέπει να δώσεις μία λέξη");
                    }
            }
        public static void proccessword(Stage stage, Partida currentpartida) throws IOException
            {
                String checkedstring;
               
                        checkedstring=getrandomword(currentpartida.getdifficulty());
                        currentpartida.setlexi(checkedstring);
                        currentpartida.getlexi().pinakessetup();
                        currentpartida.getlexi().setlines();
                        addgrammatahandlers(stage, currentpartida);
                        currentpartida.getlexi().addlettertexts(currentpartida.getcurrentwordpane().getplayingpane());
                        System.out.println("Checked String = " +  checkedstring);
                        currentpartida.getcurrentwordpane().getprospathies().setId("prospathies");
                        currentpartida.getcurrentwordpane().getprospathies().setLayoutX(1600);
                        currentpartida.getcurrentwordpane().getprospathies().setLayoutY(150);
                        currentpartida.getcurrentwordpane().getprospathies().setText(""+currentpartida.gettries());
                        currentpartida.getcurrentwordpane().getplayingpane().getChildren().remove(currentpartida.getcurrentwordpane().getwordf());
                        currentpartida.getcurrentwordpane().getplayingpane().getChildren().add(currentpartida.getcurrentwordpane().getprospathies());
                        //currentpartida.getcurrentwordpane().getplayingpane().getChildren().remove(Paiktis.getPaiktes().get(0).getNameLabel());
                        //currentpartida.getcurrentwordpane().getplayingpane().getChildren().add(Paiktis.getPaiktes().get(1).getNameLabel());
                        currentpartida.getcurrentwordpane().getcgwl().setText("Παίζει:");
                        currentpartida.getcurrentwordpane().getcgwl().setLayoutX(JavaFxTrial.getwidth()-70*JavaFxTrial.getwidth()/100);
                        Parts.addkremala(currentpartida);
                    

            }
        
        public static void checkletter(Button button, Stage stage, Partida currentpartida) throws IOException
            {   
                boolean gameover=false;
                int m=0;
                int c=0;
                
                
                    for(int o=0;o<currentpartida.getlexi().getletterssize();o++)
                        {
                            if(button.getText().equals(currentpartida.getlexi().getletters().get(o))==false)
                                {
                                    m=m+1;
                                    currentpartida.getlexi().setmistakebutton(button);
                                    currentpartida.getlexi().setcorrectbutton(null);
                                }
                            else if(button.getText().equals(currentpartida.getlexi().getletters().get(o))==true)
                                {
                                    currentpartida.getlexi().getlettertexts().get(o).setText(button.getText());
                                    currentpartida.getlexi().getletters().set(o, null);
                                    currentpartida.getlexi().setmistakebutton(null);
                                    currentpartida.getlexi().setcorrectbutton(button);
                                    Transitions.correcttransition(currentpartida.getcurrentwordpane(),currentpartida.getlexi().getcorrectbutton());
                                    //currentwordpane.getplayingpane().getChildren().remove(button);
                                }
                            else if(Character.isWhitespace(currentpartida.getlexi().getWord().charAt(o))==true)
                                {
                                    currentpartida.getlexi().getlettertexts().get(o).setText(button.getText());
                                    currentpartida.getlexi().getletters().set(o, null);
                                }
                        }

                    if(m==currentpartida.getlexi().getletters().size())
                        {
                            Parts.addbodyparts(currentpartida);
                            currentpartida.reducetries(currentpartida.getcurrentwordpane());
                            //System.out.println(currentpartida.gettries());
                            Transitions.mistaketransition(currentpartida.getcurrentwordpane(),currentpartida.getlexi().getmistakebutton());
                            currentpartida.getcurrentwordpane().getprospathies().setText(""+currentpartida.gettries());
                            //currentwordpane.getplayingpane().getChildren().remove(button);
                        }

                    for(int o=0;o<currentpartida.getlexi().getletters().size();o++)
                        {
                            if(currentpartida.getlexi().getletters().get(o)==null)
                            {
                                c=c+1;
                            }
                        }
                    
                    System.out.println("Τα spaces είναι : " + currentpartida.getlexi().getspaces());
                    System.out.println("Το c είναι : " + c);
                    System.out.println("Letters size of " + currentpartida.getlexi().getWord() + " = " + currentpartida.getlexi().getletters().size());
                    int athroisma = currentpartida.getlexi().getspaces()+c;
                    System.out.println("Αθροισμα : " + athroisma);
                    //dixegrammata();
                    currentpartida.getlexi().dixexaraktires();
                    
                    if(athroisma==currentpartida.getlexi().getletters().size())
                        {
                            Paiktis.getPaiktes().get(1).scoreplusone();
                            currentpartida.setscores();
                            currentpartida.countscore();
                            currentpartida.printscore();
                            Paiktis.swappaixtes();
                            //System.out.println(currentpartida.getlexi().getletters().size());
                            /*if(currentpartida.getscore1()==2 || currentpartida.getscore2()==2)
                                {
                                    gameover=true;
                                }
                            
                            else
                                {*/
                                    if(currentpartida.getscore1()==Partida.getnumberofpartides() || currentpartida.getscore2()==Partida.getnumberofpartides())
                                        {
                                            gameover=true;
                                        }
                                    else
                                    {
                                        Partida.neapartida(stage);
                                        gameover=false;
                                    }
                                    
                                //}
                        }
                    else if(currentpartida.gettries()==0 && athroisma!=currentpartida.getlexi().getletters().size() )
                        {
                            Paiktis.getPaiktes().get(0).scoreplusone();
                            currentpartida.setscores();
                            currentpartida.countscore();
                            currentpartida.printscore();
                            Paiktis.swappaixtes();
                            //System.out.println(currentpartida.getlexi().getletters().size());
                            
                            /*if(currentpartida.getscore1()==2 || currentpartida.getscore2()==2)
                                {
                                    //System.out.println("You lost");
                                    //Transitions.Defeat(stage, currentpartida.getlexi().getlines(), currentpartida.getlexi().getlettertexts(), currentpartida.getcurrentwordpane());
                                    gameover=true;
                                }
                            else
                                {*/
                                    
                                    if(currentpartida.getscore1()==Partida.getnumberofpartides() || currentpartida.getscore2()==Partida.getnumberofpartides())
                                        {
                                           gameover=true;
                                        }
                                    else
                                        {
                                            Partida.neapartida(stage);
                                            gameover=false; 
                                        }
                                //}
                        }
                    
                    
                    if(gameover==true)
                        {
                            Transitions.Victory(stage,currentpartida.getlexi().getlines(), currentpartida.getlexi().getlettertexts(), currentpartida);
                        }
            }
        
        private static String to_utf8(String fieldvalue) throws UnsupportedEncodingException
            {
                String fieldvalue_utf8 = new String(fieldvalue.getBytes("ISO-8859-1"), "UTF-8");
                return fieldvalue_utf8;
            }

        public static String getrandomword(String Difficulty) throws FileNotFoundException, IOException
            {   
                if(Difficulty.equals("Easy"))
                    {
                        RandomAccessFile Easy = new RandomAccessFile("src/Words/Easy.txt","r");
                        String randomword;
                        int line=0;
                        Random random = new Random();
                        line=Math.abs(random.nextInt(5));
                        Easy.seek(line);
                        randomword=Easy.readUTF();
                        Easy.close();
                        return to_utf8(randomword);
                    }
                else if(Difficulty.equals("Hard"))
                    {
                        RandomAccessFile Hard = new RandomAccessFile("src/Words/Hard.txt","r");
                        String randomword;
                        int line=0;
                        Random random = new Random();
                        line=Math.abs(random.nextInt(24));
                        Hard.seek(line);
                        randomword=Hard.readLine();
                        Hard.close();
                        return to_utf8(randomword);
                    }
                else
                    {   
                            /*FileInputStream Impossibru = new FileInputStream("src/Words/Impossibru.txt");
                            InputStreamReader reader = new InputStreamReader(Impossibru,StandardCharsets.UTF_8);

                            ArrayList<Character> word = new ArrayList<>();
                            
                        
                        String randomword;
                        int line=0;
                        Random random = new Random();
                        line=Math.abs(random.nextInt(25));
                        Impossibru.seek(line);
                        randomword=Impossibru.readLine();
                        Impossibru.close();*/
                        return null;
                    }
                
            }
    }
